<!--
// php script to enter network credentials to a wpa_supplicant.conf file.
//
// the script is a workaround because the PI can not scan for networks while hostapd is running
//
// only very basic plausibilty check of input credentials so be carefull by entering gabage 
// and crazy special characters - you could waste your wpa_supplicant.conf 
//
// 
// *** but you can also reset the file. 
//     there is an wpa_supplicant.conf_empty to be placed in 
//     /etc/wpa_supplicant/ by you.
// 
//
//
// by raffi - SI 2018
//
//
-->
<html>
	<head>
	<title>Add a Network to your wpa_supplicant.conf file</title>

	<link rel="stylesheet" type="text/css" href="assets/css/little.css">
	<link rel="stylesheet" type="text/css" href="assets/css/fonts.css">
	</head>

	<body>

	<h2>Enter network credentials:</h2>
	<form action="addnet.php" method='post'>
	<br />
	SSID<small> (min 1 char)</small><br/>
	<input name='ssid' type='text' /><br />
	<br />
	PASSWORD<small> (min 8 char)</small><br/>
	<input name="passw" type="text" /><br />
	<br /> 
	<input type='submit' value='add network' class="btn">
	<br />
	</form>
	<form action="<?=$_SERVER['PHP_SELF'];?>" method="post">
    	<input type="submit" name="clear_config" value="clear config" class="btn">
	</form>	

	<?php
	
	$ssid = $_POST['ssid'];
	$passw = $_POST ['passw'];

	if ( isset($_POST['clear_config'])) {
		//your code here
	        shell_exec("cp /etc/wpa_supplicant/wpa_supplicant.conf_empty /etc/wpa_supplicant/wpa_supplicant.conf");
		echo "config cleared!! ";
	}

// check that SSID has minimum 1 char and PASSW a minimum of 8 chars
	if ( (strlen($ssid)>=1) && (strlen($passw)>7) )
		{
		// write to the file through wpa_passphrase - echo it - reset variables to avoid duplicates when reloading 
		exec("wpa_passphrase {$ssid} {$passw} >> /etc/wpa_supplicant/wpa_supplicant.conf"); 
		echo "psk generated, credentials added!!";
		}
	else 
		{
		// echo "ssid or password to short! "; 
		}
	$passw = "";
	$ssid = "";
	// open the file in read mode 
	$f = fopen("/etc/wpa_supplicant/wpa_supplicant.conf", "rb");

	// Read file  line by line
	echo "<br />";
	echo "<h2>Contents of wpa_supplicant.conf:</h2><br />";
	while(! feof($f))
		{		
		echo "<code>";
		echo fgets($f). "<br /> </code>";
		}
	// close the file
	fclose($f);
	echo "<br />";

//	echo $ssid;
	?>
 								
	</body>
</html>
